(function (window, undefined) {
    'use strict';

    /*
    NOTE:
    ------
    PLACE HERE YOUR OWN JAVASCRIPT CODE IF NEEDED
    WE WILL RELEASE FUTURE UPDATES SO IN ORDER TO NOT OVERWRITE YOUR JAVASCRIPT CODE PLEASE CONSIDER WRITING YOUR SCRIPT HERE.  */

})(window);

$('.header-home').click(function (e) {
    $(".fixed_footer").css("display", "none")
});

$(document).ready(function () {
    var tabWrapper = $('#tab-block'),
        tabMnu = tabWrapper.find('.tab-mnu  li'),
        tabContent = tabWrapper.find('.tab-cont > .tab-pane');
    tabContent.not(':first-child').hide();
    tabMnu.each(function (i) {
        $(this).attr('data-tab', 'tab' + i);
    });
    tabContent.each(function (i) {
        $(this).attr('data-tab', 'tab' + i);
    });
    tabMnu.click(function () {
        var tabData = $(this).data('tab');
        tabWrapper.find(tabContent).hide();
        tabWrapper.find(tabContent).filter('[data-tab=' + tabData + ']').show();
    });
    $('.tab-mnu > li').click(function () {
        var before = $('.tab-mnu li.active');
        before.removeClass('active');
        $(this).addClass('active');
    });
});


$(document).ready(function () {
    var tabWrapper = $('#tab-block1'),
        tabMnu = tabWrapper.find('.tab-mnu  li'),
        tabContent = tabWrapper.find('.tab-cont > .tab-pane');
    tabContent.not(':first-child').hide();
    tabMnu.each(function (i) {
        $(this).attr('data-tab', 'tab' + i);
    });
    tabContent.each(function (i) {
        $(this).attr('data-tab', 'tab' + i);
    });
    tabMnu.click(function () {
        var tabData = $(this).data('tab');
        tabWrapper.find(tabContent).hide();
        tabWrapper.find(tabContent).filter('[data-tab=' + tabData + ']').show();
    });
    $('.tab-mnu > li').click(function () {
        var before = $('.tab-mnu li.active');
        before.removeClass('active');
        $(this).addClass('active');
    });
});

$(document).ready(function () {
    var tabWrapper = $('#tab-block2'),
        tabMnu = tabWrapper.find('.tab-mnu  li'),
        tabContent = tabWrapper.find('.tab-cont > .tab-pane');
    tabContent.not(':first-child').hide();
    tabMnu.each(function (i) {
        $(this).attr('data-tab', 'tab' + i);
    });
    tabContent.each(function (i) {
        $(this).attr('data-tab', 'tab' + i);
    });
    tabMnu.click(function () {
        var tabData = $(this).data('tab');
        tabWrapper.find(tabContent).hide();
        tabWrapper.find(tabContent).filter('[data-tab=' + tabData + ']').show();
    });
    $('.tab-mnu > li').click(function () {
        var before = $('.tab-mnu li.active');
        before.removeClass('active');
        $(this).addClass('active');
    });
});


$(document).ready(function () {
    var tabWrapper = $('#tab-block3'),
        tabMnu = tabWrapper.find('.tab-mnu  li'),
        tabContent = tabWrapper.find('.tab-cont > .tab-pane');
    tabContent.not(':first-child').hide();
    tabMnu.each(function (i) {
        $(this).attr('data-tab', 'tab' + i);
    });
    tabContent.each(function (i) {
        $(this).attr('data-tab', 'tab' + i);
    });
    tabMnu.click(function () {
        var tabData = $(this).data('tab');
        tabWrapper.find(tabContent).hide();
        tabWrapper.find(tabContent).filter('[data-tab=' + tabData + ']').show();
    });
    $('.tab-mnu > li').click(function () {
        var before = $('.tab-mnu li.active');
        before.removeClass('active');
        $(this).addClass('active');
    });
});

$(document).ready(function () {
    var tabWrapper = $('#tab-block4'),
        tabMnu = tabWrapper.find('.tab-mnu  li'),
        tabContent = tabWrapper.find('.tab-cont > .tab-pane');
    tabContent.not(':first-child').hide();
    tabMnu.each(function (i) {
        $(this).attr('data-tab', 'tab' + i);
    });
    tabContent.each(function (i) {
        $(this).attr('data-tab', 'tab' + i);
    });
    tabMnu.click(function () {
        var tabData = $(this).data('tab');
        tabWrapper.find(tabContent).hide();
        tabWrapper.find(tabContent).filter('[data-tab=' + tabData + ']').show();
    });
    $('.tab-mnu > li').click(function () {
        var before = $('.tab-mnu li.active');
        before.removeClass('active');
        $(this).addClass('active');
    });
});


$(document).ready(function () {
    var tabWrapper = $('#tab-block5'),
        tabMnu = tabWrapper.find('.tab-mnu  li'),
        tabContent = tabWrapper.find('.tab-cont > .tab-pane');
    tabContent.not(':first-child').hide();
    tabMnu.each(function (i) {
        $(this).attr('data-tab', 'tab' + i);
    });
    tabContent.each(function (i) {
        $(this).attr('data-tab', 'tab' + i);
    });
    tabMnu.click(function () {
        var tabData = $(this).data('tab');
        tabWrapper.find(tabContent).hide();
        tabWrapper.find(tabContent).filter('[data-tab=' + tabData + ']').show();
    });
    $('.tab-mnu > li').click(function () {
        var before = $('.tab-mnu li.active');
        before.removeClass('active');
        $(this).addClass('active');
    });
});


$(document).ready(function () {
    var tabWrapper = $('#tab-block6'),
        tabMnu = tabWrapper.find('.tab-mnu  li'),
        tabContent = tabWrapper.find('.tab-cont > .tab-pane');
    tabContent.not(':first-child').hide();
    tabMnu.each(function (i) {
        $(this).attr('data-tab', 'tab' + i);
    });
    tabContent.each(function (i) {
        $(this).attr('data-tab', 'tab' + i);
    });
    tabMnu.click(function () {
        var tabData = $(this).data('tab');
        tabWrapper.find(tabContent).hide();
        tabWrapper.find(tabContent).filter('[data-tab=' + tabData + ']').show();
    });
    $('.tab-mnu > li').click(function () {
        var before = $('.tab-mnu li.active');
        before.removeClass('active');
        $(this).addClass('active');
    });
});


$(document).ready(function () {
    var tabWrapper = $('#tab-block7'),
        tabMnu = tabWrapper.find('.tab-mnu  li'),
        tabContent = tabWrapper.find('.tab-cont > .tab-pane');
    tabContent.not(':first-child').hide();
    tabMnu.each(function (i) {
        $(this).attr('data-tab', 'tab' + i);
    });
    tabContent.each(function (i) {
        $(this).attr('data-tab', 'tab' + i);
    });
    tabMnu.click(function () {
        var tabData = $(this).data('tab');
        tabWrapper.find(tabContent).hide();
        tabWrapper.find(tabContent).filter('[data-tab=' + tabData + ']').show();
    });
    $('.tab-mnu > li').click(function () {
        var before = $('.tab-mnu li.active');
        before.removeClass('active');
        $(this).addClass('active');
    });
});

$(document).ready(function () {
    var tabWrapper = $('#tab-block8'),
        tabMnu = tabWrapper.find('.tab-mnu  li'),
        tabContent = tabWrapper.find('.tab-cont > .tab-pane');
    tabContent.not(':first-child').hide();
    tabMnu.each(function (i) {
        $
        $(this).attr('data-tab', 'tab' + i);
    });
    tabContent.each(function (i) {
        $(this).attr('data-tab', 'tab' + i);
    });
    tabMnu.click(function () {
        var tabData = $(this).data('tab');
        tabWrapper.find(tabContent).hide();
        tabWrapper.find(tabContent).filter('[data-tab=' + tabData + ']').show();
    });
    $('.tab-mnu > li').click(function () {
        var before = $('.tab-mnu li.active');
        before.removeClass('active');
        $(this).addClass('active');
    });
});

$('.claims-box').click(function (e) {
    $(".fixed_footer").css("display", "block")

    if ($('.claims-btn').hasClass("active")) {
        $('.claims-btn').removeClass("active");
    }
    else {
        $('.claims-btn').addClass("active");
    }
});

$('.subrogation-box').click(function (e) {
    $(".fixed_footer").css("display", "block")

    if ($('.subrogation-btn').hasClass("active")) {
        $('.subrogation-btn').removeClass("active");
    }
    else {
        $('.subrogation-btn').addClass("active");
    }
});

$('.experience-box').click(function (e) {
    $(".fixed_footer").css("display", "block")

    if ($('.experience-btn').hasClass("active")) {
        $('.experience-btn').removeClass("active");
    }
    else {
        $('.experience-btn').addClass("active");
    }
});

$('.eligibility-box').click(function (e) {
    $(".fixed_footer").css("display", "block")

    if ($('.eligibility-btn').hasClass("active")) {
        $('.eligibility-btn').removeClass("active");
    }
    else {
        $('.eligibility-btn').addClass("active");
    }
});

$('.provider-box').click(function (e) {
    $(".fixed_footer").css("display", "block")

    if ($('.provider-btn').hasClass("active")) {
        $('.provider-btn').removeClass("active");
    }
    else {
        $('.provider-btn').addClass("active");
    }
});

$('.fraud-box').click(function (e) {
    $(".fixed_footer").css("display", "block")

    if ($('.fraud-btn').hasClass("active")) {
        $('.fraud-btn').removeClass("active");
    }
    else {
        $('.fraud-btn').addClass("active");
    }
});

$('.claims-box').click(function (e) {
    $(".fixed_footer").css("display", "block")

    if ($('.claims-btn').hasClass("active")) {
        $('.claims-btn').removeClass("active");
    }
    else {
        $('.claims-btn').addClass("active");
    }
});

$('.risk-box').click(function (e) {
    $(".fixed_footer").css("display", "block")

    if ($('.risk-btn').hasClass("active")) {
        $('.risk-btn').removeClass("active");
    }
    else {
        $('.risk-btn').addClass("active");
    }
});